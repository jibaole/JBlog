jQuery(document).ready(function($){
	$('.meta-color').wpColorPicker();
});