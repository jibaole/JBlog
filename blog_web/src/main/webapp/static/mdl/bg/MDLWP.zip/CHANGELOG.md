## v1.1.2 (July 14, 2015)
- ribbon content padding
- default body color

## v1.1.1 (July 14, 2015)
- fix gulp task

## v1.1.0 (July 14, 2015)
- new ribbon page template
- moved around container classes for easier page templates
- gulp zip task
- minor code formatting

## v1.0.1 (July 12, 2015)
- WP Customizer support (pick primary and accent colors)
- remove sass link color


## v1.0.0 (July 11, 2015)
- initial commit